import { test, expect, Browser, Page } from '@playwright/test';

let browser: Browser;
let page: Page;

test.describe('Kanban Application Tests', () => {
    
    test('Accessing the main page', async ({ page }) => {
        await page.goto('https://kanban-566d8.firebaseapp.com/');
        await expect(page.getByRole('img', { name: 'logo' }), 'The page did not load correctly').toBeEnabled();
    });

    test('Edit a card and move it to the first column', async ({ page }) => {
        await page.goto('https://kanban-566d8.firebaseapp.com/');
        await expect(page.getByRole('img', { name: 'logo' }), 'The page did not load correctly').toBeEnabled();

        await test.step('Select a card that is not in the first column and has uncompleted subtasks', async () => {
            const cards = page.locator('.flex.gap-6 > section:not(:first-child) .flex.flex-col > article');
            const cardCount = await cards.count();
            
            if (cardCount === 0) {
                console.log('No available cards to edit.');
                return;
            }

            // Click on the first card that meets the criteria
            const firstCard = cards.first();
            const cardTitle = await firstCard.locator('h3').innerText(); // Capture the card title
            await firstCard.click();
        });

        await test.step('Mark an uncompleted subtask', async () => {
            const checkLabels = page.locator('label.cursor-pointer.bg-light-grey');
            const checkboxCount = await checkLabels.count();

            if (checkboxCount > 0) {
                let markedSubtasks = 0;
                for (let i = 0; i < checkboxCount; i++) {
                    const checkbox = checkLabels.nth(i).locator('input[type="checkbox"]');
                    if (!(await checkbox.isChecked())) {
                        await checkLabels.nth(i).click();
                        markedSubtasks++;

                        // Verify that the completed subtask is strikethrough
                        const completedSubtask = checkLabels.nth(i).locator('span');
                        await expect(completedSubtask).toHaveCSS('text-decoration', /line-through/);
                        break; // Mark only one subtask
                    }
                }
                if (markedSubtasks === 0) {
                    console.log('No subtasks were marked.');
                }
            } else {
                console.log('No subtasks found.');
            }
        });

        await test.step('Move the card to the first column', async () => {
            const dropdown = page.locator('.text-sm.text-black.dark\:text-white.font-bold.rounded.px-4.py-3.relative.w-full.flex.items-center.border');
            await dropdown.click();
            await page.waitForSelector('.hidden.absolute.rounded.left-0.top-full.mt-4.w-full.bg-white.dark\:bg-dark-grey.group-focus\:block > div.p-4');

            const options = page.locator('.hidden.absolute.rounded.left-0.top-full.mt-4.w-full.bg-white.dark\:bg-dark-grey.group-focus\:block > div.p-4');
            if (await options.count() > 0) {
                await options.first().click(); // Move to the first column
            } else {
                console.log('No options in the dropdown menu.');
                return;
            }
        });

        await test.step('Close the edit modal', async () => {
            // Click on the modal background to close it
            await page.locator('div.fixed.min-h-screen.min-w-full.bg-black.bg-opacity-50.top-0.left-0.z-10[data-no-dragscroll]')
            .waitFor({ state: 'visible' });

            await page.locator('div.fixed.min-h-screen.min-w-full.bg-black.bg-opacity-50.top-0.left-0.z-10[data-no-dragscroll]').click();

            // Verify that the modal has closed
            await expect.soft(page.locator('div.fixed.min-h-screen.min-w-full.bg-black.bg-opacity-50.top-0.left-0.z-10[data-no-dragscroll=""]')).not.toBeVisible();
        });

        await test.step('Verify that the card was moved to the first column', async () => {
            const cardInColumn1 = page.locator('.flex.gap-6 > section:nth-child(1) .flex.flex-col > article');
            await expect(cardInColumn1.first()).toBeVisible();

            // Verify that the moved card is the same one we edited
            const movedCardTitle = await cardInColumn1.first().locator('h3').innerText();
            await expect(movedCardTitle).toBe(movedCardTitle);
        });
    });
});
